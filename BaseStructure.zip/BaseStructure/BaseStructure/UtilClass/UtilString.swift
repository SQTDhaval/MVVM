//
//  UtilString.swift
//  iRich App
//
//  Created by MAC0008 on 08/01/19.
//  Copyright © 2019 MAC0008. All rights reserved.
//

import UIKit

class UtilString: NSObject
{
    static let CustomerCode = "Customer"
    static let CommunityCode = "Community"
    static let RoleCode = "IRich"
}
