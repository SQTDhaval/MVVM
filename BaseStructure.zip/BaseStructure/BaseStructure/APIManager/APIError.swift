//
//  APIError.swift
//  BaseStructure
//
//  Created by MAC0008 on 10/01/20.
//  Copyright © 2020 MAC0008. All rights reserved.
//

import Foundation

enum APIError: Error
{
    case generic(message: String)
}
