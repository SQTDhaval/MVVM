//
//  APIManager.swift
//  BaseStructure
//
//  Created by MAC0008 on 10/01/20.
//  Copyright © 2020 MAC0008. All rights reserved.
//

import Foundation
import Moya

struct APIManager {
   static let environment: APIEnvironment = .developement
}
