//
//  enums.swift
//  BaseStructure
//
//  Created by MAC0008 on 20/09/19.
//  Copyright © 2019 MAC0008. All rights reserved.
//

enum category: String
{
    case Default = "Default"
    case Other = "Other"
}
